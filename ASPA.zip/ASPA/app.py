DEV_MODE = True

from config import DevConfig

import pyotp
import qrcode
import io
import base64
import os

from functools import wraps
from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    send_file
)

# ================= MODULE IMPORTS =================

from modules.endpoint.endpoint_scan import endpoint_assessment
from modules.network import network_scan
from modules.email.email_scan import email_security_assessment
from modules.web.web_scan import web_security_assessment

from engine.risk import calculate_network_risk
from engine.posture import calculate_overall_posture
from engine.pdf_report import generate_pdf_report
from engine.recommendations.unified import generate_recommendations
from engine.mitre import map_mitre_attack

from utils.validator import is_valid_ip, is_valid_domain
from models.scan_model import init_db, save_scan, get_scan_history
from engine.correlation.attack_correlation import correlate_attacks

# ================= APP SETUP =================

app = Flask(__name__)
app.config.from_object(DevConfig)
init_db()

# ================= DEMO USER =================

USER_DATA = {
    "email": "admin@aspa.com",
    "password": "admin123",
    "totp_secret": pyotp.random_base32(),
    "otp_enabled": False
}

# ================= AUTH DECORATOR =================

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if DEV_MODE:
            return f(*args, **kwargs)
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

# ================= FORCE LOGIN =================

@app.before_request
def force_login():
    if DEV_MODE:
        return

    allowed_routes = {
        "login", "otp", "setup_otp", "static",
        "index", "modules", "dashboard",
        "guidance", "blog", "contact",
        "start_assessment", "download_report"
    }

    if request.endpoint and request.endpoint not in allowed_routes:
        if not session.get("logged_in"):
            return redirect(url_for("login"))

# ================= LOGIN =================

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None

    if request.method == "POST":
        if (
            request.form.get("email") != USER_DATA["email"]
            or request.form.get("password") != USER_DATA["password"]
        ):
            error = "Invalid email or password"
        else:
            session["auth_step"] = "otp"
            return redirect(url_for("otp"))

    return render_template("login.html", error=error)

# ================= OTP =================

MAX_OTP_ATTEMPTS = 3

@app.route("/otp", methods=["GET", "POST"])
def otp():
    if session.get("auth_step") != "otp":
        return redirect(url_for("login"))

    totp = pyotp.TOTP(USER_DATA["totp_secret"])
    session.setdefault("otp_attempts", 0)
    error = None

    if request.method == "POST":
        if totp.verify(request.form.get("otp")):
            session.clear()
            session["logged_in"] = True
            USER_DATA["otp_enabled"] = True
            return redirect(url_for("index"))

        session["otp_attempts"] += 1
        error = "Invalid Google Authenticator code"

        if session["otp_attempts"] >= MAX_OTP_ATTEMPTS:
            session.clear()
            return redirect(url_for("login"))

    if not USER_DATA["otp_enabled"]:
        return redirect(url_for("setup_otp"))

    return render_template("otp.html", error=error)

# ================= OTP SETUP =================

@app.route("/setup-otp")
def setup_otp():
    totp = pyotp.TOTP(USER_DATA["totp_secret"])
    uri = totp.provisioning_uri(
        name=USER_DATA["email"],
        issuer_name="ASPA Security"
    )

    img = qrcode.make(uri)
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    qr_code = base64.b64encode(buffer.getvalue()).decode()

    return render_template("setup_otp.html", qr_code=qr_code)

# ================= LOGOUT =================

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ================= HOME =================

@app.route("/")
@login_required
def index():
    return render_template("index.html")

# ================= START ASSESSMENT =================

@app.route("/start-assessment", methods=["POST"])
@login_required
def start_assessment():
    target = request.form.get("target")

    if not target or not (is_valid_ip(target) or is_valid_domain(target)):
        return render_template(
            "index.html",
            error="Invalid IP address or domain format"
        )

    report = {"target": target}

    # ---------- Endpoint ----------
    endpoint_report = endpoint_assessment(target)
    report["endpoint"] = {
        "risk": endpoint_report["risk_level"],
        "score": endpoint_report["security_score"],
        "ports": endpoint_report["open_ports"],
        "scan_context": {
            "scan_type": "Endpoint Common Port Scan",
            "ports_checked": 4,
            "note": "Only common endpoint service ports were scanned."
        }
    }

    # ---------- Network ----------
    network_ports = network_scan(target)
    network_risk, network_score = calculate_network_risk(network_ports)

    report["network"] = {
        "risk": network_risk,
        "score": network_score,
        "ports": network_ports,
        "scan_context": {
            "scan_type": "Common Network Port Scan",
            "ports_checked": 6,
            "note": "Firewall or non-standard ports may hide services."
        }
    }

    # ---------- Email ----------
    report["email"] = email_security_assessment(target)

    # ---------- Web ----------
    report["web"] = web_security_assessment(target)

    # ---------- Overall ----------
    overall_score, overall_risk = calculate_overall_posture(report)
    report["overall"] = {
        "score": overall_score,
        "risk": overall_risk
    }

    # ---------- MITRE ATT&CK ----------
    report["mitre"] = map_mitre_attack(report)
    
    # ---------- Attack Correlation ----------
    report["attack_chains"] = correlate_attacks(report)

    # ---------- Recommendations ----------
    report["recommendations"] = generate_recommendations(report)

    # ---------- Persist ----------
    save_scan(report)
    session["report"] = report

    return redirect(url_for("dashboard"))

# ================= DASHBOARD =================

@app.route("/dashboard")
@login_required
def dashboard():
    report = session.get("report")
    history = get_scan_history(limit=8)

    return render_template(
        "dashboard.html",
        report=report,
        history=history
    )

# ================= DOWNLOAD PDF =================

@app.route("/download-report")
@login_required
def download_report():
    report = session.get("report")

    if not report:
        return redirect(url_for("dashboard"))

    os.makedirs("reports/exports", exist_ok=True)
    file_path = "reports/exports/ASPA_Security_Report.pdf"

    generate_pdf_report(report, file_path)

    return send_file(
        file_path,
        as_attachment=True,
        download_name="ASPA_Security_Report.pdf"
    )

# ================= STATIC PAGES =================

@app.route("/modules")
@login_required
def modules():
    return render_template("modules.html")

@app.route("/guidance")
@login_required
def guidance():
    return render_template("guidance.html")

@app.route("/blog")
@login_required
def blog():
    return render_template("blog.html")

@app.route("/contact")
@login_required
def contact():
    return render_template("contact.html")

# ================= RUN =================

if __name__ == "__main__":
    app.run(debug=True)