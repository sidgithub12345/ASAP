import socket

COMMON_PORTS = {
    21: "FTP",
    22: "SSH",
    23: "Telnet",
    80: "HTTP",
    443: "HTTPS",
    3389: "RDP"
}

def network_scan(target):
    open_ports = []
    ports_checked = len(COMMON_PORTS)

    for port, service in COMMON_PORTS.items():
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex((target, port))

            if result == 0:
                open_ports.append({
                    "port": port,
                    "service": service
                })

            sock.close()
        except:
            pass

    return {
        "open_ports": open_ports,
        "ports_checked": ports_checked
    }