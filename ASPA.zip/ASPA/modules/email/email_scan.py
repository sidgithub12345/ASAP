from dns.resolver import resolve, NXDOMAIN, NoAnswer, Timeout


def check_dns_record(name, record_type):
    try:
        resolve(name, record_type)
        return True
    except (NXDOMAIN, NoAnswer, Timeout):
        return False
    except Exception:
        return False


def email_security_assessment(domain):
    report = {
        "spf": False,
        "dkim": False,
        "dmarc": False,
        "risk": "Unknown",
        "score": 0
    }

    # SPF
    report["spf"] = check_dns_record(domain, "TXT")

    # DKIM (default selector)
    report["dkim"] = check_dns_record(
        f"default._domainkey.{domain}", "TXT"
    )

    # DMARC
    report["dmarc"] = check_dns_record(
        f"_dmarc.{domain}", "TXT"
    )

    # Score calculation
    score = 0
    if report["spf"]:
        score += 30
    if report["dkim"]:
        score += 30
    if report["dmarc"]:
        score += 40

    report["score"] = score

    if score >= 80:
        report["risk"] = "Low"
    elif score >= 40:
        report["risk"] = "Medium"
    else:
        report["risk"] = "High"

    return report