import subprocess
import platform

def check_host_alive(target):
    """
    Checks if host is alive using ICMP ping
    Supports Windows and Linux/macOS
    """
    try:
        system = platform.system().lower()

        if system == "windows":
            command = ["ping", "-n", "1", "-w", "2000", target]
        else:
            command = ["ping", "-c", "1", "-W", "2", target]

        result = subprocess.run(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        return result.returncode == 0

    except subprocess.SubprocessError:
        return False
    except Exception:
        return False