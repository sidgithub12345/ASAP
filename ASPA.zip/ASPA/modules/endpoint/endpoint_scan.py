import socket
import datetime

COMMON_PORTS = {
    22: "SSH",
    80: "HTTP",
    443: "HTTPS",
    3389: "RDP"
}

def check_host_alive(target, port=80):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        result = sock.connect_ex((target, port))
        sock.close()
        return result == 0
    except Exception:
        return False

def scan_ports(target):
    open_ports = []

    for port, service in COMMON_PORTS.items():
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex((target, port))
            if result == 0:
                open_ports.append({"port": port, "service": service})
            sock.close()
        except socket.error:
            pass
    return open_ports


def calculate_risk(open_ports):
    if len(open_ports) == 0:
        return "Low", 90
    elif len(open_ports) <= 2:
        return "Medium", 70
    else:
        return "High", 40


def endpoint_assessment(target):
    report = {
        "target": target,
        "timestamp": str(datetime.datetime.now()),
        "host_alive": False,
        "open_ports": [],
        "risk_level": "Unknown",
        "security_score": 0
    }

    if not check_host_alive(target):
        report["risk_level"] = "High"
        report["security_score"] = 20
        return report

    report["host_alive"] = True

    open_ports = scan_ports(target)
    risk, score = calculate_risk(open_ports)

    report["open_ports"] = open_ports
    report["risk_level"] = risk
    report["security_score"] = score

    return report