import requests

SECURITY_HEADERS = {
    "Strict-Transport-Security": "HSTS",
    "Content-Security-Policy": "CSP",
    "X-Frame-Options": "XFO",
    "X-Content-Type-Options": "XCTO",
    "Referrer-Policy": "Referrer Policy"
}

def web_security_assessment(domain):
    report = {
        "https": False,
        "headers": {},
        "risk": "Unknown",
        "score": 0
    }

    try:
        response = requests.get(
            f"https://{domain}",
            timeout=5,
            allow_redirects=True
        )

        report["https"] = True
        headers = response.headers

        # HTTPS baseline score
        score = 30

        for header, label in SECURITY_HEADERS.items():
            present = header in headers
            report["headers"][label] = present
            if present:
                score += 14

        report["score"] = min(score, 100)

    except Exception:
        report["https"] = False
        report["headers"] = {label: False for label in SECURITY_HEADERS.values()}
        report["score"] = 0

    # Risk evaluation
    if report["score"] >= 80:
        report["risk"] = "Low"
    elif report["score"] >= 40:
        report["risk"] = "Medium"
    else:
        report["risk"] = "High"

    return report