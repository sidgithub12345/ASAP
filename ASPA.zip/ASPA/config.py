class Config:
    """
    Base configuration for ASPA application
    """
    SECRET_KEY = "aspa-super-secret-key"
    SESSION_PERMANENT = False
    SESSION_USE_SIGNER = True


class DevConfig(Config):
    """
    Development configuration
    """
    DEBUG = True


class ProdConfig(Config):
    """
    Production configuration (future use)
    """
    DEBUG = False