def calculate_network_risk(open_ports):
    count = len(open_ports)

    if count == 0:
        return "Low", 90
    elif count <= 2:
        return "Medium", 70
    else:
        return "High", 40