def correlate_attacks(report):
    chains = []

    # Chain 1: Endpoint + Network
    if report["endpoint"]["ports"] and report["network"]["risk"] in ["Medium", "High"]:
        chains.append({
            "name": "External Service Exploitation",
            "severity": "High",
            "steps": [
                "Service Discovery (T1046)",
                "Remote Service Access (T1133)",
                "Lateral Movement (T1021)"
            ],
            "description": (
                "Exposed services combined with network exposure allow attackers "
                "to gain initial access and move laterally."
            )
        })

    # Chain 2: Web → Phishing
    if not report["web"]["headers"].get("CSP") and not report["email"]["dkim"]:
        chains.append({
            "name": "Phishing + Web Injection",
            "severity": "High",
            "steps": [
                "Drive-by Compromise (T1189)",
                "Phishing (T1566)",
                "Credential Harvesting (T1056)"
            ],
            "description": (
                "Missing CSP allows malicious scripts, while missing DKIM "
                "enables phishing-based credential theft."
            )
        })

    # Chain 3: Email Only
    if report["email"]["risk"] == "High":
        chains.append({
            "name": "Email Spoofing Attack",
            "severity": "Medium",
            "steps": [
                "Email Spoofing",
                "Phishing Link Delivery",
                "User Credential Capture"
            ],
            "description": (
                "Weak email authentication allows spoofed emails "
                "to compromise users."
            )
        })

    return chains