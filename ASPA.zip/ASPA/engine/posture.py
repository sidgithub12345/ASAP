def calculate_overall_posture(report):
    weights = {
        "endpoint": 0.40,
        "network": 0.35,
        "email": 0.25
    }

    total_score = 0

    if "endpoint" in report:
        total_score += report["endpoint"]["score"] * weights["endpoint"]

    if "network" in report:
        total_score += report["network"]["score"] * weights["network"]

    if "email" in report:
        total_score += report["email"].get("score", 0) * weights["email"]

    final_score = round(total_score)

    if final_score >= 75:
        risk = "Low"
    elif final_score >= 45:
        risk = "Medium"
    else:
        risk = "High"

    return final_score, risk