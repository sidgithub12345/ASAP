def generate_score(risk_value):
    score = 100 - risk_value
    return max(score, 0)
