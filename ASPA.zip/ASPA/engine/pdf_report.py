from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm
from datetime import datetime


def generate_pdf_report(report, file_path):
    c = canvas.Canvas(file_path, pagesize=A4)
    width, height = A4

    y = height - 2 * cm

    def draw_line(text):
        nonlocal y
        c.drawString(2 * cm, y, text)
        y -= 0.8 * cm

    # ================= HEADER =================
    c.setFont("Helvetica-Bold", 18)
    draw_line("ASPA – Automated Security Posture Analysis")

    c.setFont("Helvetica", 11)
    draw_line(f"Generated on: {datetime.now().strftime('%d %b %Y, %H:%M')}")

    y -= 0.5 * cm
    c.line(2 * cm, y, width - 2 * cm, y)
    y -= 1 * cm

    # ================= OVERALL =================
    c.setFont("Helvetica-Bold", 14)
    draw_line("Overall Security Posture")

    c.setFont("Helvetica", 11)
    draw_line(f"Target: {report['target']}")
    draw_line(f"Overall Score: {report['overall']['score']} / 100")
    draw_line(f"Overall Risk: {report['overall']['risk']}")

    y -= 0.5 * cm

    # ================= ENDPOINT =================
    c.setFont("Helvetica-Bold", 13)
    draw_line("Endpoint Security")

    c.setFont("Helvetica", 11)
    draw_line(f"Risk Level: {report['endpoint']['risk']}")
    draw_line(f"Score: {report['endpoint']['score']} / 100")

    if report['endpoint']['ports']:
        draw_line("Open Ports:")
        for port in report['endpoint']['ports']:
            draw_line(f"- {port['service']} (Port {port['port']})")
    else:
        draw_line("No exposed endpoint services detected.")

    y -= 0.5 * cm

    # ================= NETWORK =================
    c.setFont("Helvetica-Bold", 13)
    draw_line("Network Security")

    c.setFont("Helvetica", 11)
    draw_line(f"Risk Level: {report['network']['risk']}")
    draw_line(f"Score: {report['network']['score']} / 100")

    if report['network']['ports']:
        draw_line("Open Ports:")
        for port in report['network']['ports']:
            draw_line(f"- {port['service']} (Port {port['port']})")
    else:
        draw_line("No exposed network services detected.")

    y -= 0.5 * cm

    # ================= EMAIL =================
    c.setFont("Helvetica-Bold", 13)
    draw_line("Email Security")

    c.setFont("Helvetica", 11)
    draw_line(f"Risk Level: {report['email']['risk']}")
    draw_line(f"Score: {report['email']['score']} / 100")
    draw_line(f"SPF: {'Enabled' if report['email']['spf'] else 'Missing'}")
    draw_line(f"DKIM: {'Enabled' if report['email']['dkim'] else 'Missing'}")
    draw_line(f"DMARC: {'Enabled' if report['email']['dmarc'] else 'Missing'}")

    c.showPage()
    c.save()
