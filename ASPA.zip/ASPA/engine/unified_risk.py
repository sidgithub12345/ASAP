def calculate_overall_risk(endpoint, network, email):
    """
    endpoint = { risk, score }
    network  = { risk, score }
    email    = { risk, score }
    """

    weights = {
        "endpoint": 0.4,
        "network": 0.35,
        "email": 0.25
    }

    final_score = (
        endpoint["score"] * weights["endpoint"] +
        network["score"] * weights["network"] +
        email["score"] * weights["email"]
    )

    final_score = round(final_score)

    if final_score >= 80:
        risk_level = "Low"
    elif final_score >= 45:
        risk_level = "Medium"
    else:
        risk_level = "High"

    return {
        "score": final_score,
        "risk_level": risk_level
    }
