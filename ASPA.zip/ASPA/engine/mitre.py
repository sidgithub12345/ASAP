def map_mitre_attack(report):
    mitre_findings = []

    # ================= ENDPOINT =================
    if report["endpoint"]["ports"]:
        severity = 7 if len(report["endpoint"]["ports"]) > 2 else 5

        mitre_findings.append({
            "tactic": "Discovery",
            "technique_id": "T1046",
            "technique": "Network Service Discovery",
            "module": "Endpoint",
            "severity_score": severity,
            "severity": "High" if severity >= 7 else "Medium",
            "reason": "Open endpoint services allow attackers to enumerate running services."
        })

    # ================= NETWORK =================
    if report["network"]["risk"] in ["High", "Medium"]:
        severity = 8 if report["network"]["risk"] == "High" else 6

        mitre_findings.append({
            "tactic": "Initial Access",
            "technique_id": "T1133",
            "technique": "External Remote Services",
            "module": "Network",
            "severity_score": severity,
            "severity": "High" if severity >= 7 else "Medium",
            "reason": "Exposed network services may allow unauthorized remote access."
        })

    # ================= WEB =================
    if not report["web"]["headers"].get("Content-Security-Policy"):
        severity = 9

        mitre_findings.append({
            "tactic": "Initial Access",
            "technique_id": "T1189",
            "technique": "Drive-by Compromise",
            "module": "Web",
            "severity_score": severity,
            "severity": "Critical",
            "reason": "Missing Content Security Policy allows malicious script execution."
        })

    # ================= EMAIL =================
    if not report["email"]["dkim"]:
        severity = 6

        mitre_findings.append({
            "tactic": "Initial Access",
            "technique_id": "T1566",
            "technique": "Phishing",
            "module": "Email",
            "severity_score": severity,
            "severity": "Medium",
            "reason": "Missing DKIM enables email spoofing and phishing attacks."
        })

    return mitre_findings