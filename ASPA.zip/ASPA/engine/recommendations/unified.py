from engine.recommendations.endpoint import endpoint_recommendations
from engine.recommendations.network import network_recommendations
from engine.recommendations.web import web_recommendations
from engine.recommendations.email import email_recommendations

def generate_recommendations(report):
    return {
        "endpoint": endpoint_recommendations(report["endpoint"]),
        "network": network_recommendations(report["network"]),
        "web": web_recommendations(report["web"]),
        "email": email_recommendations(report["email"])
    }