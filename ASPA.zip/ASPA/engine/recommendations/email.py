def email_recommendations(email_report):
    recs = []

    if not email_report["spf"]:
        recs.append({
            "issue": "SPF missing",
            "risk": "Email spoofing possible",
            "fix": "Configure SPF record in DNS"
        })

    if not email_report["dkim"]:
        recs.append({
            "issue": "DKIM missing",
            "risk": "Email integrity not guaranteed",
            "fix": "Enable DKIM signing"
        })

    if not email_report["dmarc"]:
        recs.append({
            "issue": "DMARC missing",
            "risk": "No policy enforcement",
            "fix": "Add DMARC policy with monitoring"
        })

    if not recs:
        recs.append({
            "issue": "Email security strong",
            "risk": "Low",
            "fix": "Continue monitoring DNS records"
        })

    return recs
