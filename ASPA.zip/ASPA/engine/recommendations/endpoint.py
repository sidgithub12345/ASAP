def endpoint_recommendations(endpoint_report):
    recs = []

    if endpoint_report["risk"] == "High":
        recs.append({
            "issue": "High endpoint exposure",
            "risk": "Unpatched or vulnerable services detected",
            "fix": "Apply latest OS patches and disable unused services"
        })

    if endpoint_report["ports"]:
        recs.append({
            "issue": "Open services detected",
            "risk": "Increases attack surface",
            "fix": "Restrict ports using firewall rules"
        })

    if not recs:
        recs.append({
            "issue": "Endpoint hardened",
            "risk": "No immediate risk",
            "fix": "Maintain regular patching and monitoring"
        })

    return recs
