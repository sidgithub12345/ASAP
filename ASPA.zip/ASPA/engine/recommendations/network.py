def network_recommendations(network_report):
    recs = []

    if network_report["risk"] == "High":
        recs.append({
            "issue": "Exposed network services",
            "risk": "Remote exploitation possible",
            "fix": "Close unused ports and restrict access via firewall"
        })

    if not network_report["ports"]:
        recs.append({
            "issue": "Minimal exposure",
            "risk": "Low network attack surface",
            "fix": "Continue monitoring periodically"
        })

    return recs
