def web_recommendations(web_report):
    recs = []

    if not web_report["https"]:
        recs.append({
            "issue": "HTTPS not enforced",
            "risk": "Man-in-the-middle attacks possible",
            "fix": "Enable HTTPS with a valid TLS certificate"
        })

    for header, present in web_report["headers"].items():
        if not present:
            recs.append({
                "issue": f"Missing {header} header",
                "risk": "Weak browser-side protection",
                "fix": f"Configure {header} in server response headers"
            })

    if not recs:
        recs.append({
            "issue": "Web configuration secure",
            "risk": "Low",
            "fix": "Maintain secure headers and TLS"
        })

    return recs
