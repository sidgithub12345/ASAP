import sqlite3
from datetime import datetime

DB_PATH = "database/aspa.db"


def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS scan_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            target TEXT,
            endpoint_score INTEGER,
            network_score INTEGER,
            web_score INTEGER,
            email_score INTEGER,
            overall_score INTEGER,
            overall_risk TEXT,
            scanned_at TEXT
        )
    """)

    conn.commit()
    conn.close()


def save_scan(report):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO scan_history (
            target,
            endpoint_score,
            network_score,
            web_score,
            email_score,
            overall_score,
            overall_risk,
            scanned_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        report["target"],
        report["endpoint"]["score"],
        report["network"]["score"],
        report["web"]["score"],
        report["email"]["score"],
        report["overall"]["score"],
        report["overall"]["risk"],
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ))

    conn.commit()
    conn.close()


def get_scan_history(limit=10):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT target, overall_score, overall_risk, scanned_at
        FROM scan_history
        ORDER BY scanned_at DESC
        LIMIT ?
    """, (limit,))

    rows = cursor.fetchall()
    conn.close()

    return rows
