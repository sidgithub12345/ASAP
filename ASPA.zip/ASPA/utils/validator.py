import re
import ipaddress

def is_valid_domain(domain: str) -> bool:
    """
    Validates a domain name using regex
    """
    if not domain:
        return False

    domain = domain.strip().lower()

    pattern = r"^(?!-)[A-Za-z0-9-]{1,63}(?<!-)(\.[A-Za-z]{2,})+$"
    return bool(re.fullmatch(pattern, domain))


def is_valid_ip(ip: str) -> bool:
    """
    Validates IPv4 address using ipaddress module
    """
    try:
        ipaddress.IPv4Address(ip)
        return True
    except ipaddress.AddressValueError:
        return False