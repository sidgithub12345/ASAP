from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from datetime import datetime


def generate_security_report(report, file_path):
    c = canvas.Canvas(file_path, pagesize=A4)
    width, height = A4

    y = height - 50

    # ================= HEADER =================
    c.setFont("Helvetica-Bold", 20)
    c.drawString(50, y, "ASPA – Security Assessment Report")

    y -= 30
    c.setFont("Helvetica", 11)
    c.drawString(50, y, f"Generated On: {datetime.now().strftime('%d %b %Y, %H:%M')}")

    y -= 40
    c.line(50, y, width - 50, y)
    y -= 30

    # ================= TARGET =================
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "Target Information")

    y -= 20
    c.setFont("Helvetica", 12)
    c.drawString(50, y, f"Target: {report['target']}")

    y -= 30

    # ================= OVERALL =================
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "Overall Security Posture")

    y -= 20
    c.setFont("Helvetica", 12)
    c.drawString(50, y, f"Score: {report['overall']['score']} / 100")
    y -= 18
    c.drawString(50, y, f"Risk Level: {report['overall']['risk']}")

    y -= 30

    # ================= ENDPOINT =================
    endpoint = report["endpoint"]
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "Endpoint Security")

    y -= 20
    c.setFont("Helvetica", 12)
    c.drawString(50, y, f"Risk: {endpoint['risk']}")
    y -= 18
    c.drawString(50, y, f"Score: {endpoint['score']} / 100")

    y -= 30

    # ================= NETWORK =================
    network = report["network"]
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "Network Security")

    y -= 20
    c.setFont("Helvetica", 12)
    c.drawString(50, y, f"Risk: {network['risk']}")
    y -= 18
    c.drawString(50, y, f"Score: {network['score']} / 100")

    y -= 25
    if network["ports"]:
        c.drawString(50, y, "Open Ports:")
        y -= 18
        for port in network["ports"]:
            c.drawString(70, y, f"- {port['service']} (Port {port['port']})")
            y -= 15
    else:
        c.drawString(50, y, "No exposed network services detected.")

    y -= 30

    # ================= EMAIL =================
    email = report["email"]
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "Email Security")

    y -= 20
    c.setFont("Helvetica", 12)
    c.drawString(50, y, f"SPF: {'Yes' if email['spf'] else 'No'}")
    y -= 15
    c.drawString(50, y, f"DKIM: {'Yes' if email['dkim'] else 'No'}")
    y -= 15
    c.drawString(50, y, f"DMARC: {'Yes' if email['dmarc'] else 'No'}")
    y -= 15
    c.drawString(50, y, f"Risk: {email['risk']}")

    y -= 30

    # ================= WEB =================
    web = report["web"]
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "Web Security")

    y -= 20
    c.setFont("Helvetica", 12)
    c.drawString(50, y, f"HTTPS Enabled: {'Yes' if web['https'] else 'No'}")
    y -= 15
    c.drawString(50, y, f"Security Headers: {web['headers_score']} / 100")

    # ================= FOOTER =================
    c.showPage()
    c.save()
